
<div class="product-details__order">
            <h3 class="product-details__order-heading">Contact Sales</h3>
            <div class="product-details__order-link-wrapper">
            <a href="tel:919747317773" class="product-details__order-link">
                <img src="assets/images/contact-sales-phone-icon.svg" alt="contact-sales-phone-icon" class="product-details__order-link-icon">
                <span class="product-details__order-number">+91-9747317773</span>
            </a>
            </div>
        </div>