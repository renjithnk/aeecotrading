<?php $page='pdp'; ?>
<?php include('includes/site-header.php') ?>

<main class="site-content">

<div class="subpage-banner-pdp container">
    <div class="subpage-banner-pdp__content">
    
            <!-- <div class="subpage-banner-pdp__details">
                <h2 class="subpage-banner-pdp__details-heading">Ultra Filtration</h2>
                <p class="subpage-banner-pdp__details-description">Micro Control Based Fully Automatic Ultra Filtration</p>
            </div> -->
        </div>
        <div class="subpage-banner-pdp__bg">
            <div class="subpage-banner-pdp__bg-strip1"></div>
            <div class="subpage-banner-pdp__bg-strip2"></div>
            <div class="subpage-banner-pdp__bg-strip3"></div>
    </div>
</div>    


<div class="breadcrumbs container">
        <ul class="breadcrumbs__ul">
        <li class="breadcrumbs__li">
            <a href="index.php" class="breadcrumbs__a">Home</a>
        </li>
        <li class="breadcrumbs__li">
            <a href="products.php" class="breadcrumbs__a">Products</a>
        </li>
        <li class="breadcrumbs__li">
            <a href="blowers.php" class="breadcrumbs__a">Blowers</a>
        </li>
        <li class="breadcrumbs__li">
            <a href="blowers-everest.php" class="breadcrumbs__a">Everest Blowers</a>
        </li>
        <li class="breadcrumbs__li">Ingersoll Rand Everest Twin Lobe Positive Displacement Air Blower</li>
        </ul>
    </div>

<div class="product-details content-section">
    <div class="product-details__container container">
    <div class="product-details__col1">
        <div class="piczoomer">
        <img src="assets/images/ingersoll-rand-everest-twin-lobe-positive-displacement-air-blowers-lg.webp" alt="cutter-pumpset" class="product-details__image" width="450" height="450">
            </div>
        </div>
        <div class="product-details__col2">
        <h2 class="product-details__name">Ingersoll Rand Everest Twin Lobe Positive Displacement Air Blower</h2>
        <img src="assets/images/brands-everest-logo-thumb.svg" class="product-details__brand" alt="havells">
        
        <p class="product-details__description"></p>
        <div class="product-details__description-block">
            <h3 class="product-details__description-block-heading">Overview</h3>
            <p class="product-details__description-block-description">Twin-lobe compressors/blowers are positive displacement units with two two-lobe (8-shaped) impellers mounted on parallel shafts, rotating in opposite directions within a casing. Their pumping capacity is determined by size, operating speed, and pressure conditions. Twin-lobe blowers are ideal for applications and processes that require pressures of around 250 to 450 millibars (3.6 to 6.5psig) in rather short periods of use.</p>
        </div>
        
        <?php include('includes/pdp-contact-sales.php') ?>

     </div>
    </div>
</div>
        

</main>

<?php include('includes/site-footer.php') ?>


<!-- Main JS-->
<script type="module" src="assets/js/scripts.js"></script>
</body>

</html>